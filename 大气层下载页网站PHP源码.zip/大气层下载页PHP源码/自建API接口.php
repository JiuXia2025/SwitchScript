<?php
/**
 * API
 *
 * @author    JiuXia2025
 * @version    V1.0
 */
$url = 'https://api.github.com/repos/JiuXia2025/SwitchScript/releases/latest';
$cacheFile = 'cache.txt';
$cacheDuration = 24 * 60 * 60; // 设置1天缓存

// 检查缓存文件
if (file_exists($cacheFile) && time() - filemtime($cacheFile) < $cacheDuration) {
    // 读取文件缓存
    $content = file_get_contents($cacheFile);
} else {
    // 调用curl模拟客户端请求
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 6.0; Windows NT 6.1; Trident/5.1)');
    $content = curl_exec($curl);
    curl_close($curl);

    // 保存数据至缓存文件
    file_put_contents($cacheFile, $content);
}

echo $content;
?>