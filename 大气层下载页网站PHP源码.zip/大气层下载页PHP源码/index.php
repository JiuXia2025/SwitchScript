<?php
/**
 * Package Download Page
 *
 * @author    JiuXia2025
 * @version    V1.0
 */
//获取API，可以自己搭建填你搭建API的链接，九夏的不保证一
//也可以填github官方的，但是github限制每天只能请求5000次
//自建API会缓存1天完美规避限制，API源码在压缩包里另一个文件，可以填你的搭建的API绝对地址，哪天九夏的用不了了你就替换成你的就行了
$url = "http://appcenter.9xia.top/latest_release.php";
// 获取JSON数据
$jsonData = file_get_contents($url);
// 解析JSON数据
$data = json_decode($jsonData);
// 获取browser_download_url和updated_at的值
$node3 = $data->assets[0]->browser_download_url;
$updatedAt = $data->assets[0]->updated_at;
$name = $data->name;
$body = $data->body;
$body = str_replace("\n","<br/>",$body);
$node1 = str_replace("https://github.com/","https://mirror.ghproxy.com/https://github.com/",$node3);
$node2 = str_replace("https://github.com/","https://hub.fgit.cf/",$node3);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>大气层最新整合包</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="九夏大气层整合包，是一款可以一键安装Atmosphere+hetake+nro/nsp插件+tesla插件等的整合包。" />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="http://kangle.cccyun.cn/style.css">
<style>
	h4 span {
    font-size: 0.9em;
    margin-left: 5px;
    color: #999;
    font-weight: 400;
	}
	.site-footer-credits a {
	color: #819198;
	}
	section div{
	margin-bottom: 30px;
	}
	.highlighter-rouge{
	margin-bottom: 20px;
	}
</style>
<script>
function stop(){
return false;
}
document.oncontextmenu=stop;
</script>
</head>
<body>
<section class="page-header">
<h1 class="project-name">大气层整合包</h1>
<h2 class="project-tagline"><?php echo"$updatedAt"; ?></h2>
<a href="<?php echo"$node1"; ?>" target="_blank" class="btn">下载最新构建(线路1)</a>
<a href="<?php echo"$node2"; ?>" target="_blank" class="btn">下载最新构建(线路2)</a>
<a href="<?php echo"$node3"; ?>" target="_blank" class="btn">下载最新构建(线路3)</a>
<a href="https://github.com/JiuXia2025/SwitchScript" target="_blank" class="btn">开源地址</a>
</section>
<section class="main-content">
<div>
<h1><a href="#header-info"></a>整合简介</h1>
<div>
<p>九夏大气层整合包，是一款可以一键安装Atmosphere+hetake+nro/nsp插件+tesla插件等的整合包。
整合包本身集成：Atmosphere、hetake、payload工具包，支持官方最新系统，打包最新插件与组件。同时也对配置文件进行了大量优化。<br />
</p>
</div>
</div>
<div>
<h2><a href="#header-point"></a>关于整合</h2>
<div>
<blockquote>
<p>本整合包永久开源免费，禁止任何人二次贩卖本整合包，公开转载请注明整合包来源@JiuXia2025<br />
特斯拉菜单按键：L+Zl+R，hbmenu插件菜单按键：按住R点击相册(防止小孩误点操作)<br />
整合包如有问题反馈建议讨论相关的请加QQ群：952060192 ，看到会回复的，推荐加一下出问题方便解决<br />
整合包由JiuXia2025二改定制@huangqian8脚本后打包而成，加入了一些原有脚本未包含的内容并且会持续更新<br />
整合包自动构建，请下载最新release使用。所有大气层相关组件与插件自动同步上游最新版本，构建过程全公开不夹带私货，安全放心开箱即用</p>
</blockquote>
</div>
<div id="hideCity">
<h2><a href="#header-point"></a>整合内容</h2>
<div>
<blockquote>
<p><?php echo"$name"; ?></p>
<p>
<?php echo"$body"; ?>
</p>
</blockquote>
</div>
</div>
<div>
<h2><a href="#header-attention"></a>安装方式</h2>
<div>
<p>
1.下载大气层整合包<br/>
2.删除原有整合包相关文件<br/>
3.解压下载的大气层整合包<br/>
4.把解压出来的SwitchSD目录所有文件复制到内存卡里<br/>
</p>
</div>
</div>
</div>
</div>
</div>
<footer class="site-footer">
<span class="site-footer-owner">All rights reserved <a href="https://github.com/JiuXia2025">JiuXia2025</a>.</span>
</footer>
</section>
</body>
</html>